
from django.contrib import messages                        # Mensajes de éxito y error
from django.contrib.auth.decorators import login_required  # NUEVO (4.5): protege las vistas
from django.core.paginator import Paginator                # Corta una lista en páginas
from django.db.models import ProtectedError, Q                # Error al borrar una marca que tiene productos
from django.shortcuts import render, redirect, get_object_or_404

from .forms import MarcaForm, ProductoForm, CategoriaForm, ClienteForm, PerfilForm
from .models import Marca, Producto, Categoria, Cliente, Perfil


# =====================================================================
# MARCAS · Vistas Basadas en Funciones (VBF)
# =====================================================================

@login_required                                            # NUEVO (4.5): exige iniciar sesión
def marca_lista(request):                                  # READ: muestra todas las marcas
    q = request.GET.get("q", "")                           # 1. Leemos el buscador
    marcas = Marca.objects.all()                           # 2. Pedimos todas las marcas a la base de datos

    if q:                                                  # 3. Si el usuario escribió algo en el buscador...
        marcas = marcas.filter(nombre__icontains=q)        #    ...dejamos solo las que contienen ese texto

    contexto = {                                           # 4. Datos que enviamos al template
        "titulo": "Marcas",                                #    → {{ titulo }}
        "marcas": marcas,                                  #    → {% for marca in marcas %}
        "q": q,                                            #    → para que el buscador no se borre
    }
    return render(request, "facturacion/marca_lista.html", contexto)


@login_required                                            # NUEVO (4.5): exige iniciar sesión
def marca_crear(request):                                  # CREATE: crear una marca nueva

    if request.method == "POST":                           # ¿El usuario presionó "Guardar"?
        form = MarcaForm(request.POST)                     # 1. Llenamos el formulario con lo que escribió
        if form.is_valid():                                # 2. ¿Los datos están bien?
            marca = form.save()                            # 3. Guardamos en la base de datos
            messages.success(request, f"Marca «{marca.nombre}» creada correctamente.")
            return redirect("facturacion:marca_lista")     # 4. Volvemos a la lista

    else:                                                  # Si llegó por GET...
        form = MarcaForm()                                 # ...creamos un formulario vacío

    contexto = {
        "titulo": "Nueva marca",
        "form": form,
        "boton": "Guardar",
    }
    return render(request, "facturacion/marca_form.html", contexto)


@login_required                                            # NUEVO (4.5): exige iniciar sesión
def marca_editar(request, pk):                             # UPDATE
    marca = get_object_or_404(Marca, pk=pk)                # Buscamos la marca o mostramos 404

    if request.method == "POST":                           # ¿Presionó "Actualizar"?
        form = MarcaForm(request.POST, instance=marca)     # Datos nuevos + marca existente
        if form.is_valid():                                # ¿Están bien?
            form.save()                                    # Actualiza, no crea una nueva
            messages.success(request, f"Marca «{marca.nombre}» actualizada.")
            return redirect("facturacion:marca_lista")
    else:                                                  # Llegó por GET...
        form = MarcaForm(instance=marca)                   # Formulario con los datos actuales

    contexto = {
        "titulo": f"Editar marca: {marca.nombre}",
        "form": form,
        "boton": "Actualizar",
    }
    return render(request, "facturacion/marca_form.html", contexto)


@login_required                                            # NUEVO (4.5): exige iniciar sesión
def marca_eliminar(request, pk):                           # DELETE
    marca = get_object_or_404(Marca, pk=pk)                # Buscamos la marca o mostramos 404

    if request.method == "POST":                           # ¿Presionó "Sí, eliminar"?
        try:                                               # Intentamos borrar...
            nombre = marca.nombre                          # Guardamos el nombre para el mensaje
            marca.delete()                                 # DELETE en la base de datos
            messages.success(request, f"Marca «{nombre}» eliminada.")
        except ProtectedError:                             # Si tiene productos, PROTECT no deja borrarla
            messages.error(request, f"No se puede eliminar «{marca.nombre}» porque tiene productos. Desactívala en su lugar.")
        return redirect("facturacion:marca_lista")         # En los dos casos volvemos a la lista

    # Si llegó por GET: mostramos la pregunta "¿Seguro?"
    contexto = {"titulo": "Eliminar marca", "marca": marca}
    return render(request, "facturacion/marca_eliminar.html", contexto)


# =====================================================================
# PRODUCTOS · Vistas Basadas en Funciones (VBF)
# =====================================================================

@login_required                                            # NUEVO (4.5): exige iniciar sesión
def producto_lista(request):                               # READ: lista de productos con buscador y páginas
    q = request.GET.get("q", "")                           # 1. Texto del buscador: /productos/?q=laptop (si no hay, "")

    productos = (                                          # 2. Pedimos los productos a la base de datos
        Producto.objects
        .select_related("marca")                           #    1:N → trae la marca en la MISMA consulta (JOIN)
        .prefetch_related("categorias")                    #    N:M → trae todas las categorías en UNA consulta extra
    )                                                      #    Sin estas 2 líneas la tabla haría 2 consultas POR CADA producto

    if q:                                                  # 3. Si escribió algo en el buscador...
        productos = productos.filter(nombre__icontains=q)  #    ...dejamos solo los que contienen ese texto

    paginador = Paginator(productos, 5)                    # 4. Corta la lista de 5 en 5
    numero = request.GET.get("page")                       # 5. ¿Qué página pidió? /productos/?page=2 (si no hay, None)
    page_obj = paginador.get_page(numero)                  # 6. Esa página. Si piden ?page=abc da la 1; si piden ?page=99, la última

    contexto = {
        "titulo": "Productos",                             # → {{ titulo }}
        "page_obj": page_obj,                              # → {% for producto in page_obj %} (solo trae los 5 de esta página)
        "q": q,                                            # → para que el buscador no se borre
    }
    return render(request, "facturacion/producto_lista.html", contexto)


@login_required                                            # NUEVO (4.5): exige iniciar sesión
def producto_crear(request):                               # CREATE: crear un producto nuevo

    if request.method == "POST":                           # ¿Presionó "Guardar"? (llegó por POST)
        form = ProductoForm(request.POST)                  # 1. Llenamos el formulario con lo que envió
        if form.is_valid():                                # 2. ¿Todo bien? (obligatorios, marca existe, clean_precio...)
            producto = form.save()                         # 3. INSERT del producto + INSERT de sus categorías (N:M)
            messages.success(request, f"Producto «{producto.nombre}» creado.")
            return redirect("facturacion:producto_lista")  # 4. A la lista (Post/Redirect/Get)
        # Si NO es válido, baja hasta el render y muestra el formulario CON errores

    else:                                                  # Llegó por GET (abrió la página)...
        form = ProductoForm()                              # ...formulario vacío

    contexto = {
        "titulo": "Nuevo producto",
        "form": form,                                      # Vacío (GET) o con datos y errores (POST inválido)
        "boton": "Guardar",
    }
    return render(request, "facturacion/producto_form.html", contexto)


@login_required                                            # NUEVO (4.5): exige iniciar sesión
def producto_editar(request, pk):                          # UPDATE. pk viene de la URL: /productos/editar/7/ → pk=7
    producto = get_object_or_404(Producto, pk=pk)          # 1. Buscamos el producto. Si no existe → página 404

    if request.method == "POST":                           # 2. ¿Presionó "Actualizar"?
        form = ProductoForm(request.POST, instance=producto)   # Datos nuevos + el producto que vamos a cambiar
        if form.is_valid():
            form.save()                                    # UPDATE del producto y reemplaza sus categorías por las marcadas
            messages.success(request, f"Producto «{producto.nombre}» actualizado.")
            return redirect("facturacion:producto_lista")
        messages.error(request, "Revisa los campos marcados en rojo.")   # Solo llega aquí si NO es válido
    else:                                                  # 3. Llegó por GET...
        form = ProductoForm(instance=producto)             #    ...formulario LLENO con los datos actuales (y sus casillas marcadas)

    contexto = {
        "titulo": f"Editar producto: {producto.nombre}",
        "form": form,
        "boton": "Actualizar",
    }
    return render(request, "facturacion/producto_form.html", contexto)   # El mismo template de crear


@login_required                                            # NUEVO (4.5): exige iniciar sesión
def producto_detalle(request, pk):                         # READ (uno): la ficha de un producto
    producto = get_object_or_404(Producto, pk=pk)          # Buscamos el producto número pk o mostramos 404
    contexto = {"producto": producto}                      # Solo necesitamos enviar el producto
    return render(request, "facturacion/producto_detalle.html", contexto)
    # Esta vista solo atiende GET: no tiene formulario, así que no pregunta por request.method


@login_required                                            # NUEVO (4.5): exige iniciar sesión
def producto_eliminar(request, pk):                        # DELETE
    producto = get_object_or_404(Producto, pk=pk)          # Buscamos el producto o mostramos 404

    if request.method == "POST":                           # ¿Presionó "Sí, eliminar"?
        nombre = producto.nombre                           # Guardamos el nombre para el mensaje
        producto.delete()                                  # DELETE del producto y de sus filas en la tabla intermedia
        messages.success(request, f"Producto «{nombre}» eliminado.")   # (la marca y las categorías NO se borran)
        return redirect("facturacion:producto_lista")

    # Llegó por GET: mostramos la pregunta "¿Seguro?"
    contexto = {"titulo": "Eliminar producto", "producto": producto}
    return render(request, "facturacion/producto_eliminar.html", contexto)

    # Llegó por GET: mostramos la pregunta "¿Seguro?"
    contexto = {"titulo": "Eliminar producto", "producto": producto}
    return render(request, "facturacion/producto_eliminar.html", contexto)



# =====================================================================
# TAREA · CATEGORÍAS · Vistas Basadas en Funciones (VBF)
# =====================================================================

@login_required
def categoria_lista(request):                              # READ: mostrar y buscar categorías
    q = request.GET.get("q", "")                           # GET: leemos el texto del buscador
    categorias = Categoria.objects.all()                   # Obtenemos todas las categorías

    if q:
        categorias = categorias.filter(nombre__icontains=q)  # Buscar sin distinguir mayúsculas

    contexto = {
        "titulo": "Categorías",
        "categorias": categorias,
        "q": q,
    }
    return render(request, "facturacion/categoria_lista.html", contexto)


@login_required
def categoria_crear(request):                              # CREATE: registrar categoría
    if request.method == "POST":                           # POST: el usuario envió el formulario
        form = CategoriaForm(request.POST)
        if form.is_valid():
            categoria = form.save()                        # Guardamos la nueva categoría
            messages.success(request, f"Categoría «{categoria.nombre}» creada correctamente.")
            return redirect("facturacion:categoria_lista")
    else:                                                  # GET: mostramos formulario vacío
        form = CategoriaForm()

    contexto = {
        "titulo": "Nueva categoría",
        "form": form,
        "boton": "Guardar",
    }
    return render(request, "facturacion/categoria_form.html", contexto)


@login_required
def categoria_editar(request, pk):                         # UPDATE: modificar categoría
    categoria = get_object_or_404(Categoria, pk=pk)

    if request.method == "POST":                           # POST: recibimos los cambios
        form = CategoriaForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            messages.success(request, f"Categoría «{categoria.nombre}» actualizada.")
            return redirect("facturacion:categoria_lista")
    else:                                                  # GET: formulario con los datos actuales
        form = CategoriaForm(instance=categoria)

    contexto = {
        "titulo": f"Editar categoría: {categoria.nombre}",
        "form": form,
        "boton": "Actualizar",
    }
    return render(request, "facturacion/categoria_form.html", contexto)


@login_required
def categoria_eliminar(request, pk):                       # DELETE: eliminar categoría

    # Solo los usuarios staff pueden eliminar categorías
    if not request.user.is_staff:
        messages.error(request, "No tienes permisos para eliminar categorías.")
        return redirect("facturacion:categoria_lista")

    categoria = get_object_or_404(Categoria, pk=pk)

    if request.method == "POST":                           # POST: confirmó la eliminación
        nombre = categoria.nombre
        categoria.delete()
        messages.success(request, f"Categoría «{nombre}» eliminada.")
        return redirect("facturacion:categoria_lista")

    # GET: mostramos la página de confirmación
    contexto = {
        "titulo": "Eliminar categoría",
        "categoria": categoria,
    }
    return render(request, "facturacion/categoria_eliminar.html", contexto)

# =====================================================================
# TAREA: CLIENTES · Vistas Basadas en Funciones (VBF)
# =====================================================================

@login_required
def cliente_lista(request):                               # READ: listar y buscar clientes
    q = request.GET.get("q", "")                           # GET: texto ingresado en el buscador
    clientes = Cliente.objects.all()                       # Obtenemos todos los clientes

    if q:
        clientes = clientes.filter(Q(apellidos__icontains=q) | Q(nombres__icontains=q)
)
    # Paginación: mostrar 5 clientes por página
    paginador = Paginator(clientes, 5)
    numero = request.GET.get("page")                       # GET: número de página solicitado
    page_obj = paginador.get_page(numero)

    contexto = {
        "titulo": "Clientes",
        "page_obj": page_obj,
        "q": q,
    }
    return render(request, "facturacion/cliente_lista.html", contexto)


@login_required
def cliente_crear(request):                               # CREATE: registrar cliente
    if request.method == "POST":                          # POST: el usuario envió el formulario
        form = ClienteForm(request.POST)

        if form.is_valid():
            cliente = form.save()
            messages.success(
                request,
                f"Cliente «{cliente.nombres} {cliente.apellidos}» creado correctamente."
            )
            return redirect("facturacion:cliente_lista")

    else:                                                 # GET: mostrar formulario vacío
        form = ClienteForm()

    contexto = {
        "titulo": "Nuevo cliente",
        "form": form,
        "boton": "Guardar",
    }
    return render(request, "facturacion/cliente_form.html", contexto)


@login_required
def cliente_editar(request, pk):                          # UPDATE: modificar cliente
    cliente = get_object_or_404(Cliente, pk=pk)

    if request.method == "POST":                          # POST: guardar los cambios
        form = ClienteForm(request.POST, instance=cliente)

        if form.is_valid():
            form.save()
            messages.success(
                request,
                f"Cliente «{cliente.nombres} {cliente.apellidos}» actualizado."
            )
            return redirect("facturacion:cliente_lista")

    else:                                                 # GET: mostrar datos actuales
        form = ClienteForm(instance=cliente)

    contexto = {
        "titulo": f"Editar cliente: {cliente.nombres} {cliente.apellidos}",
        "form": form,
        "boton": "Actualizar",
    }
    return render(request, "facturacion/cliente_form.html", contexto)


@login_required
def cliente_eliminar(request, pk):                        # DELETE: eliminar cliente

    # Solo los usuarios staff pueden eliminar clientes
    if not request.user.is_staff:
        messages.error(request, "No tienes permisos para eliminar clientes.")
        return redirect("facturacion:cliente_lista")

    cliente = get_object_or_404(Cliente, pk=pk)

    if request.method == "POST":                          # POST: confirmar eliminación
        nombre = f"{cliente.nombres} {cliente.apellidos}"
        cliente.delete()

        messages.success(
            request,
            f"Cliente «{nombre}» eliminado correctamente."
        )
        return redirect("facturacion:cliente_lista")

    # GET: mostrar la página de confirmación
    contexto = {
        "titulo": "Eliminar cliente",
        "cliente": cliente,
    }
    return render(request, "facturacion/cliente_eliminar.html", contexto)



# =====================================================================
# RETO 5.5: MI PERFIL · Relación uno a uno (1:1)
# =====================================================================

@login_required
def mi_perfil(request):                                  # Editar el perfil del usuario conectado

    # Buscamos el perfil del usuario que inició sesión.
    # Si todavía no existe, Django lo crea automáticamente.
    # No usamos pk porque siempre trabajamos con request.user.
    perfil, creado = Perfil.objects.get_or_create(
        usuario=request.user
    )

    if request.method == "POST":                         # POST: el usuario presionó Guardar
        form = PerfilForm(request.POST, instance=perfil) # Datos enviados + perfil existente

        if form.is_valid():                              # Verificamos que los datos sean válidos
            form.save()                                 # Actualizamos el perfil
            messages.success(
                request,
                "Tu perfil se actualizó correctamente."
            )
            return redirect("facturacion:mi_perfil")     # Regresamos a la misma página

    else:                                                # GET: el usuario abrió Mi perfil
        form = PerfilForm(instance=perfil)               # Mostramos sus datos actuales

    contexto = {
        "titulo": "Mi perfil",
        "form": form,
        "perfil": perfil,
        "boton": "Guardar cambios",
    }

    return render(request, "facturacion/mi_perfil.html", contexto)
