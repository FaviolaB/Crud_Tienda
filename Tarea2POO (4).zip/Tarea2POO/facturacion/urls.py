from django.urls import path
from . import views

app_name = "facturacion"                   # Apellido de las URLs: 'facturacion:...'

urlpatterns = [
    # ---------- MARCAS: vistas basadas en FUNCIONES ----------
    path("marcas/", views.marca_lista, name="marca_lista"),                          # Listar
    path("marcas/crear/", views.marca_crear, name="marca_crear"),                    # Crear
    path("marcas/editar/<int:pk>/", views.marca_editar, name="marca_editar"),        # Editar la marca número pk
        # ---------- PRODUCTOS (Unidad 3) ----------
    path("productos/", views.producto_lista, name="producto_lista"),   # /facturacion/productos/
    path("marcas/eliminar/<int:pk>/", views.marca_eliminar, name="marca_eliminar"),  # Eliminar la marca número pk
    path("productos/crear/", views.producto_crear, name="producto_crear"),   # /facturacion/productos/crear/
        # <int:pk> captura el número de la URL y se lo pasa a la función como parámetro pk
    path("productos/editar/<int:pk>/", views.producto_editar, name="producto_editar"),
    path("productos/<int:pk>/", views.producto_detalle, name="producto_detalle"),   # /facturacion/productos/7/
    path("productos/eliminar/<int:pk>/", views.producto_eliminar, name="producto_eliminar"),
    
    # ---------- CATEGORÍAS (TAREA) ----------
    path("categorias/", views.categoria_lista, name="categoria_lista"),
    path("categorias/crear/", views.categoria_crear, name="categoria_crear"),
    path("categorias/editar/<int:pk>/", views.categoria_editar, name="categoria_editar"),
    path("categorias/eliminar/<int:pk>/", views.categoria_eliminar, name="categoria_eliminar"),

    # ---------- CLIENTES (TAREA) ----------
    path("clientes/", views.cliente_lista, name="cliente_lista"),                     # READ: listar, buscar y paginar
    path("clientes/crear/", views.cliente_crear, name="cliente_crear"),               # CREATE: registrar cliente
    path("clientes/editar/<int:pk>/", views.cliente_editar, name="cliente_editar"),   # UPDATE: modificar cliente
    path("clientes/eliminar/<int:pk>/", views.cliente_eliminar, name="cliente_eliminar"), # DELETE: eliminar cliente

    # ---------- RETO 5.5: MI PERFIL (RELACIÓN 1:1) ----------
    path("mi-perfil/", views.mi_perfil, name="mi_perfil"),

]
