
from django import forms                                 # Herramientas de formularios
from .models import Marca, Producto, Categoria, Cliente, Perfil  # TAREA: también importamos Categoria y Cliente


class MarcaForm(forms.ModelForm):                        # Formulario de Marca, de la Unidad 2
    class Meta:
        model = Marca
        fields = ["nombre", "pais_origen", "activo"]
        labels = {"nombre": "Nombre de la marca"}
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ej: Samsung"}),
            "pais_origen": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ej: Corea del Sur"}),
            "activo": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean_nombre(self):                              # Validación propia del campo nombre
        nombre = self.cleaned_data["nombre"].strip()

        # Validar que el nombre tenga al menos 2 caracteres
        if len(nombre) < 2:
            raise forms.ValidationError(
                "El nombre debe tener al menos 2 letras."
            )

        # Buscar marcas con el mismo nombre, sin distinguir mayúsculas
        repetida = Marca.objects.filter(nombre__iexact=nombre)

        # Si estamos editando, excluir la marca actual
        if self.instance.pk:
            repetida = repetida.exclude(pk=self.instance.pk)

        # Impedir nombres duplicados
        if repetida.exists():
            raise forms.ValidationError("Esta marca ya existe.")

        return nombre.title()


class ProductoForm(forms.ModelForm):                     # Formulario de Producto
    class Meta:
        model = Producto                                 # Sale del modelo Producto
        fields = ["nombre", "descripcion", "marca", "categorias", "precio", "stock", "activo"]
        widgets = {
            "nombre": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: Laptop Pro 14",
            }),
            "descripcion": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3,
            }),
            # 1:N (ForeignKey) → se elige UNA sola marca
            "marca": forms.Select(attrs={
                "class": "form-select",
            }),
            # N:M (ManyToMany) → se pueden marcar VARIAS categorías
            "categorias": forms.CheckboxSelectMultiple(attrs={
                "class": "form-check-input",
            }),
            "precio": forms.NumberInput(attrs={
                "class": "form-control",
                "step": "0.01",
                "min": "0",
            }),
            "stock": forms.NumberInput(attrs={
                "class": "form-control",
                "min": "0",
            }),
            "activo": forms.CheckboxInput(attrs={
                "class": "form-check-input",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Mostrar únicamente las marcas activas
        self.fields["marca"].queryset = Marca.objects.filter(activo=True)
        self.fields["marca"].empty_label = "— Elige una marca —"

    def clean_precio(self):                              # Validación propia del campo precio
        precio = self.cleaned_data["precio"]

        if precio <= 0:
            raise forms.ValidationError(
                "El precio debe ser mayor que 0."
            )

        return precio


# =====================================================================
# TAREA: CATEGORÍAS · Formulario para crear y editar categorías
# =====================================================================

class CategoriaForm(forms.ModelForm):                    # Formulario basado en el modelo Categoria
    class Meta:
        model = Categoria                                # Usa la tabla facturacion_categoria
        fields = ["nombre", "descripcion", "activo"]

        labels = {
            "nombre": "Nombre de la categoría",
            "descripcion": "Descripción",
            "activo": "Activa",
        }

        widgets = {
            "nombre": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: Laptops",
            }),
            "descripcion": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3,
                "placeholder": "Descripción de la categoría",
            }),
            "activo": forms.CheckboxInput(attrs={
                "class": "form-check-input",
            }),
        }

    def clean_nombre(self):                              # Validación del nombre de la categoría
        nombre = self.cleaned_data["nombre"].strip()

        # El nombre debe tener al menos 2 caracteres
        if len(nombre) < 2:
            raise forms.ValidationError(
                "El nombre de la categoría debe tener al menos 2 caracteres."
            )

        # Buscar categorías repetidas sin distinguir mayúsculas y minúsculas
        repetida = Categoria.objects.filter(nombre__iexact=nombre)

        # Si estamos editando, excluir la categoría actual
        if self.instance.pk:
            repetida = repetida.exclude(pk=self.instance.pk)

        # Impedir categorías duplicadas
        if repetida.exists():
            raise forms.ValidationError(
                "Esta categoría ya existe."
            )

        return nombre.title()


# =====================================================================
# TAREA: CLIENTES · Formulario para crear y editar clientes
# =====================================================================

class ClienteForm(forms.ModelForm):                      # Formulario basado en el modelo Cliente
    class Meta:
        model = Cliente                                  # Usa el modelo Cliente
        fields = ["cedula", "nombres", "apellidos", "email", "telefono", "direccion"]

        labels = {
            "cedula": "Cédula",
            "nombres": "Nombres",
            "apellidos": "Apellidos",
            "email": "Correo electrónico",
            "telefono": "Teléfono",
            "direccion": "Dirección",
        }

        widgets = {
            "cedula": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: 0912345678",
                "maxlength": "10",
            }),
            "nombres": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: María",
            }),
            "apellidos": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: González",
            }),
            "email": forms.EmailInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: maria@gmail.com",
            }),
            "telefono": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: 0991234567",
            }),
            "direccion": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: Av. Principal y Calle 10",
            }),
        }

    def clean_cedula(self):                              # Validación de la cédula
        cedula = self.cleaned_data["cedula"].strip()

        # La cédula debe contener exactamente 10 números
        if len(cedula) != 10 or not cedula.isascii() or not cedula.isdigit():
            raise forms.ValidationError(
                "La cédula debe contener exactamente 10 números."
            )

        # Buscar clientes con la misma cédula
        repetida = Cliente.objects.filter(cedula=cedula)

        # Si estamos editando, excluir al cliente actual
        if self.instance.pk:
            repetida = repetida.exclude(pk=self.instance.pk)

        # Impedir cédulas duplicadas
        if repetida.exists():
            raise forms.ValidationError(
                "Ya existe un cliente registrado con esta cédula."
            )

        return cedula

    def clean_nombres(self):                             # Validación de nombres
        nombres = self.cleaned_data["nombres"].strip()

        # Los nombres deben tener al menos 2 caracteres
        if len(nombres) < 2:
            raise forms.ValidationError(
                "El nombre debe tener al menos 2 caracteres."
            )

        return nombres.title()

    def clean_apellidos(self):                           # Validación de apellidos
        apellidos = self.cleaned_data["apellidos"].strip()

        # Los apellidos deben tener al menos 2 caracteres
        if len(apellidos) < 2:
            raise forms.ValidationError(
                "El apellido debe tener al menos 2 caracteres."
            )

        return apellidos.title()


# =====================================================================
# RETO 5.5: MI PERFIL · Formulario para editar el perfil del usuario
# =====================================================================

class PerfilForm(forms.ModelForm):                       # Formulario basado en el modelo Perfil
    class Meta:
        model = Perfil                                   # Usa el modelo Perfil (relación 1:1)
        fields = ["cedula", "telefono", "direccion", "cargo"]

        # No incluimos "usuario" porque el perfil pertenece
        # automáticamente al usuario que inició sesión.

        labels = {
            "cedula": "Cédula",
            "telefono": "Teléfono",
            "direccion": "Dirección",
            "cargo": "Cargo",
        }

        widgets = {
            "cedula": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: 0912345678",
                "maxlength": "10",
            }),
            "telefono": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: 0991234567",
            }),
            "direccion": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: Av. Principal y Calle 10",
            }),
            "cargo": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: Vendedor, Cajero, Administrador",
            }),
        }
